/* main.h
 *
 * Copyright (c) 1992-2016 by Mike Gleason.
 * All rights reserved.
 * 
 */

/* main.c */
void InitConnectionInfo(void);
void CloseHost(void);
